  <!--  Scripts-->
  <script src="https://kit.fontawesome.com/1f260e2580.js" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="<?php echo base_url('assets/materialize/js/materialize.js') ?>"></script>
  <script src="<?php echo base_url('assets/materialize/js/init.js') ?>"></script>


  