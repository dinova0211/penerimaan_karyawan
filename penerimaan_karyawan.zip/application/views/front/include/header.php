<section class="site-cover"  id="section-home">
  <div class="container">
	<div class="row align-items-center justify-content-center text-center site-vh-100">
	  <div class="col-md-12">
	  
		<!--<h1 class="site-heading site-animate mb-3">SPK Pemilihan Karyawan dengan Metode WMP</h1>-->
		
		<!--<h2 class="h5 site-subheading mb-5 site-animate"> SPK Pemilihan Restaurant dengan Metode WMP</h2>-->
	  </div>
	</div>
  </div>
</section>