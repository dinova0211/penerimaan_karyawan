<div class="modal fade" id="reservationModal" tabindex="-1" role="dialog" aria-labelledby="reservationModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
	<div class="modal-content">
	  <div class="modal-body">
		<div class="row">
		  <div class="col-lg-12">
			<div class="bg-image" style="background-image: url(images/reservation_1.jpg);"></div>
		  </div>
		  <div class="col-lg-12 p-5">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <small>CLOSE </small><span aria-hidden="true">&times;</span>
			</button>

			</form>
		  </div>
		</div>
		
	  </div>
	</div>
  </div>
</div>