<script src="<?php echo base_url('assets/front2/eatwell/');?>js/jquery.min.js"></script>
<script src="<?php echo base_url('assets/front2/eatwell/');?>js/popper.min.js"></script>
<script src="<?php echo base_url('assets/front2/eatwell/');?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url('assets/front2/eatwell/');?>js/jquery.easing.1.3.js"></script>

<script src="<?php echo base_url('assets/front2/eatwell/');?>js/jquery.waypoints.min.js"></script>
<script src="<?php echo base_url('assets/front2/eatwell/');?>js/owl.carousel.min.js"></script>
<script src="<?php echo base_url('assets/front2/eatwell/');?>js/jquery.magnific-popup.min.js"></script>

<script src="<?php echo base_url('assets/front2/eatwell/');?>js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url('assets/front2/eatwell/');?>js/jquery.timepicker.min.js"></script>

<script src="<?php echo base_url('assets/front2/eatwell/');?>js/jquery.animateNumber.min.js"></script>

<!--
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD7Mr1SnmpnkqSqZZcFDXOPK0LVGJ1aqV4"></script>
<script src="<?php echo base_url('assets/front2/eatwell/');?>js/google-map.js"></script>
-->

<script src="<?php echo base_url('assets/front2/eatwell/');?>js/main.js"></script>


<script src="<?php echo base_url("assets/")?>js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url("assets/")?>js/bootstrap.js" ></script>