<head>
    <title>Penerimaan Karyawab Baru</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
	<!--
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700|Raleway" rel="stylesheet">
	-->
	 
	
	
    <link rel="stylesheet" href="<?php echo base_url('assets/front2/eatwell/');?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/front2/eatwell/');?>css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/front2/eatwell/');?>css/animate.css">
    
    <link rel="stylesheet" href="<?php echo base_url('assets/front2/eatwell/');?>css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/front2/eatwell/');?>css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/front2/eatwell/');?>css/magnific-popup.css">

    <link rel="stylesheet" href="<?php echo base_url('assets/front2/eatwell/');?>css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/front2/eatwell/');?>css/jquery.timepicker.css">

    

    <link rel="stylesheet" href="<?php echo base_url('assets/front2/eatwell/');?>css/icomoon.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/front2/eatwell/');?>css/style.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/front2/eatwell/');?>css/custom.css">
	
	<script type="text/javascript">
			window.jQuery || document.write("<script src='<?php echo base_url('assets/') ?>js/jquery.js'>"+"<"+"/script>");
		</script>
		
</head>